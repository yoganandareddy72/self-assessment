import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { bootstrapApplication } from '@angular/platform-browser';
import { Observable } from 'rxjs';

import { MonitoringService } from './services/monitoring.service';
import { Website } from './models/website.model';
import { AddWebsiteComponent } from './components/add-website/add-website.component';
import { WebsiteCardComponent } from './components/website-card/website-card.component';
import { StatsDashboardComponent } from './components/stats-dashboard/stats-dashboard.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    AddWebsiteComponent,
    WebsiteCardComponent,
    StatsDashboardComponent
  ],
  template: `
    <div class="container">
      <header class="text-center mb-8">
        <h1 class="text-3xl font-bold text-white mb-2">Website Monitor</h1>
        <p class="text-white opacity-80">Real-time website status monitoring and analytics</p>
        <div class="mt-4 mb-4">
          <button
            (click)="toggleMonitoring()"
            [class]="isMonitoring ? 'btn btn-danger' : 'btn btn-primary'"
          >
            {{ isMonitoring ? 'Stop Monitoring' : 'Start Monitoring' }}
          </button>
        </div>
        <div class="bg-white bg-opacity-20 rounded-lg p-4 mt-4">
          <p class="text-white text-sm">
            <strong>Note:</strong> Due to browser security restrictions (CORS), some websites may show as "DOWN" 
            even if they're actually accessible. This is normal behavior for client-side monitoring.
            For production use, implement server-side monitoring for accurate results.
          </p>
        </div>
      </header>

      <app-stats-dashboard></app-stats-dashboard>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-1">
          <app-add-website></app-add-website>
          
          <div class="card mt-6">
            <h3 class="text-lg font-semibold mb-3">How it works</h3>
            <ul class="text-sm text-gray-600 space-y-2">
              <li>• Attempts multiple methods to check website availability</li>
              <li>• Updates status every 30 seconds when monitoring is active</li>
              <li>• Tracks response times and uptime percentages</li>
              <li>• Shows 24-hour status history in mini charts</li>
              <li>• Data persists in browser local storage</li>
            </ul>
          </div>
        </div>
        
        <div class="lg:col-span-2">
          <div *ngIf="websites$ | async as websites">
            <div *ngIf="websites.length === 0" class="card text-center">
              <div class="text-gray-500 mb-4">
                <svg class="w-16 h-16 mx-auto mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                </svg>
                <h3 class="text-lg font-semibold mb-2">No websites being monitored</h3>
                <p>Add your first website to start monitoring its status and performance.</p>
              </div>
            </div>
            
            <div *ngIf="websites.length > 0" class="grid gap-4">
              <app-website-card
                *ngFor="let website of websites; trackBy: trackByWebsiteId"
                [website]="website"
              ></app-website-card>
            </div>
          </div>
        </div>
      </div>
      
      <footer class="mt-8 text-center text-white opacity-60">
        <p class="text-sm">
          Real-time monitoring • Auto-refresh every 30 seconds • 
          <span class="font-semibold">Last updated: {{ lastUpdate | date:'short' }}</span>
        </p>
      </footer>
    </div>
  `,
  styles: [`
    .w-16 {
      width: 4rem;
    }
    
    .h-16 {
      height: 4rem;
    }
    
    .mx-auto {
      margin-left: auto;
      margin-right: auto;
    }
    
    .opacity-50 {
      opacity: 0.5;
    }
    
    .opacity-60 {
      opacity: 0.6;
    }
    
    .opacity-80 {
      opacity: 0.8;
    }
    
    .bg-opacity-20 {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .space-y-2 > * + * {
      margin-top: 0.5rem;
    }
  `]
})
export class App implements OnInit, OnDestroy {
  websites$!: Observable<Website[]>;
  isMonitoring = false;
  lastUpdate = new Date();

  constructor(private monitoringService: MonitoringService) {}

  ngOnInit(): void {
    this.websites$ = this.monitoringService.getWebsites();
    this.startAutoRefresh();
  }

  ngOnDestroy(): void {
    this.monitoringService.stopMonitoring();
  }

  toggleMonitoring(): void {
    if (this.isMonitoring) {
      this.monitoringService.stopMonitoring();
      this.isMonitoring = false;
    } else {
      this.monitoringService.startMonitoring();
      this.isMonitoring = true;
    }
  }

  trackByWebsiteId(index: number, website: Website): string {
    return website.id;
  }

  private startAutoRefresh(): void {
    // Update timestamp every minute
    setInterval(() => {
      this.lastUpdate = new Date();
    }, 60000);
    
    // Start monitoring automatically
    setTimeout(() => {
      this.toggleMonitoring();
    }, 1000);
  }
}

bootstrapApplication(App, {
  providers: []
});