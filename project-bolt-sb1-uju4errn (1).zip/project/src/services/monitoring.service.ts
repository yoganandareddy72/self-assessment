import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, interval, of } from 'rxjs';
import { map, catchError, switchMap } from 'rxjs/operators';
import { Website, StatusPoint, MonitoringStats } from '../models/website.model';

@Injectable({
  providedIn: 'root'
})
export class MonitoringService {
  private websites$ = new BehaviorSubject<Website[]>([]);
  private isMonitoring = false;
  private monitoringInterval: any;

  constructor() {
    // Load websites from localStorage on init
    const savedWebsites = localStorage.getItem('monitored-websites');
    if (savedWebsites) {
      const websites = JSON.parse(savedWebsites).map((site: any) => ({
        ...site,
        lastChecked: new Date(site.lastChecked),
        statusHistory: site.statusHistory.map((point: any) => ({
          ...point,
          timestamp: new Date(point.timestamp)
        }))
      }));
      this.websites$.next(websites);
    }
  }

  getWebsites(): Observable<Website[]> {
    return this.websites$.asObservable();
  }

  addWebsite(url: string, name: string): void {
    const websites = this.websites$.value;
    const newWebsite: Website = {
      id: this.generateId(),
      url: this.normalizeUrl(url),
      name: name || this.extractDomainName(url),
      status: 'checking',
      responseTime: 0,
      lastChecked: new Date(),
      statusHistory: [],
      uptime: 100
    };

    const updatedWebsites = [...websites, newWebsite];
    this.websites$.next(updatedWebsites);
    this.saveToLocalStorage(updatedWebsites);
    
    // Check the new website immediately
    this.checkWebsite(newWebsite.id);
  }

  removeWebsite(id: string): void {
    const websites = this.websites$.value.filter(site => site.id !== id);
    this.websites$.next(websites);
    this.saveToLocalStorage(websites);
  }

  startMonitoring(): void {
    if (this.isMonitoring) return;
    
    this.isMonitoring = true;
    this.monitoringInterval = interval(30000).subscribe(() => {
      this.checkAllWebsites();
    });
    
    // Initial check
    this.checkAllWebsites();
  }

  stopMonitoring(): void {
    this.isMonitoring = false;
    if (this.monitoringInterval) {
      this.monitoringInterval.unsubscribe();
    }
  }

  getMonitoringStats(): Observable<MonitoringStats> {
    return this.websites$.pipe(
      map(websites => {
        const totalSites = websites.length;
        const activeSites = websites.filter(site => site.status === 'up').length;
        const downSites = websites.filter(site => site.status === 'down').length;
        const averageResponseTime = websites.length > 0 
          ? websites.reduce((sum, site) => sum + site.responseTime, 0) / websites.length 
          : 0;

        return {
          totalSites,
          activeSites,
          downSites,
          averageResponseTime: Math.round(averageResponseTime)
        };
      })
    );
  }

  private checkAllWebsites(): void {
    const websites = this.websites$.value;
    websites.forEach(website => {
      this.checkWebsite(website.id);
    });
  }

  private async checkWebsite(id: string): Promise<void> {
    const websites = this.websites$.value;
    const websiteIndex = websites.findIndex(site => site.id === id);
    
    if (websiteIndex === -1) return;

    const website = websites[websiteIndex];
    website.status = 'checking';
    website.lastChecked = new Date();
    
    // Update status to checking
    this.websites$.next([...websites]);

    try {
      const startTime = performance.now();
      
      // Try multiple methods to check website availability
      const isUp = await this.performWebsiteCheck(website.url);
      const endTime = performance.now();
      const responseTime = Math.round(endTime - startTime);
      
      const updatedWebsites = [...this.websites$.value];
      const currentWebsite = updatedWebsites[websiteIndex];
      
      currentWebsite.status = isUp ? 'up' : 'down';
      currentWebsite.responseTime = isUp ? responseTime : 0;
      currentWebsite.lastChecked = new Date();
      
      // Add to status history
      const statusPoint: StatusPoint = {
        timestamp: new Date(),
        status: isUp ? 'up' : 'down',
        responseTime: responseTime
      };
      
      currentWebsite.statusHistory.push(statusPoint);
      
      // Keep only last 50 points for performance
      if (currentWebsite.statusHistory.length > 50) {
        currentWebsite.statusHistory = currentWebsite.statusHistory.slice(-50);
      }
      
      // Calculate uptime percentage
      const upPoints = currentWebsite.statusHistory.filter(point => point.status === 'up').length;
      currentWebsite.uptime = currentWebsite.statusHistory.length > 0 
        ? Math.round((upPoints / currentWebsite.statusHistory.length) * 100)
        : 100;
      
      this.websites$.next(updatedWebsites);
      this.saveToLocalStorage(updatedWebsites);
      
    } catch (error) {
      // Handle error case
      const updatedWebsites = [...this.websites$.value];
      const currentWebsite = updatedWebsites[websiteIndex];
      
      currentWebsite.status = 'down';
      currentWebsite.responseTime = 0;
      currentWebsite.lastChecked = new Date();
      
      // Add to status history
      const statusPoint: StatusPoint = {
        timestamp: new Date(),
        status: 'down',
        responseTime: 0
      };
      
      currentWebsite.statusHistory.push(statusPoint);
      
      if (currentWebsite.statusHistory.length > 50) {
        currentWebsite.statusHistory = currentWebsite.statusHistory.slice(-50);
      }
      
      // Calculate uptime percentage
      const upPoints = currentWebsite.statusHistory.filter(point => point.status === 'up').length;
      currentWebsite.uptime = currentWebsite.statusHistory.length > 0 
        ? Math.round((upPoints / currentWebsite.statusHistory.length) * 100)
        : 0;
      
      this.websites$.next(updatedWebsites);
      this.saveToLocalStorage(updatedWebsites);
    }
  }

  private async performWebsiteCheck(url: string): Promise<boolean> {
    try {
      // Method 1: Try to fetch with no-cors mode (limited but can detect some failures)
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
      
      const response = await fetch(url, {
        method: 'HEAD', // Use HEAD to minimize data transfer
        mode: 'no-cors', // Bypass CORS but limits response info
        signal: controller.signal,
        cache: 'no-cache'
      });
      
      clearTimeout(timeoutId);
      
      // In no-cors mode, we can't read the status, but if fetch succeeds without error,
      // it usually means the server responded
      return true;
      
    } catch (error) {
      // If fetch fails, try alternative methods
      try {
        // Method 2: Try to load as an image (works for some servers)
        return await this.checkViaImage(url);
      } catch (imageError) {
        // Method 3: Try to create a script tag (another CORS bypass attempt)
        try {
          return await this.checkViaScript(url);
        } catch (scriptError) {
          // All methods failed, likely the site is down or unreachable
          return false;
        }
      }
    }
  }

  private checkViaImage(url: string): Promise<boolean> {
    return new Promise((resolve) => {
      const img = new Image();
      const timeout = setTimeout(() => {
        resolve(false);
      }, 8000);
      
      img.onload = () => {
        clearTimeout(timeout);
        resolve(true);
      };
      
      img.onerror = () => {
        clearTimeout(timeout);
        // Even if image fails to load, if we get an error response,
        // it might mean the server is responding
        resolve(false);
      };
      
      // Try to load favicon or a common image path
      img.src = url + '/favicon.ico';
    });
  }

  private checkViaScript(url: string): Promise<boolean> {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      const timeout = setTimeout(() => {
        document.head.removeChild(script);
        resolve(false);
      }, 8000);
      
      script.onload = () => {
        clearTimeout(timeout);
        document.head.removeChild(script);
        resolve(true);
      };
      
      script.onerror = () => {
        clearTimeout(timeout);
        document.head.removeChild(script);
        resolve(false);
      };
      
      // Try to load a common script path
      script.src = url + '/robots.txt';
      document.head.appendChild(script);
    });
  }

  private normalizeUrl(url: string): string {
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      return 'https://' + url;
    }
    return url;
  }

  private extractDomainName(url: string): string {
    try {
      const domain = new URL(this.normalizeUrl(url)).hostname;
      return domain.replace('www.', '');
    } catch {
      return url;
    }
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }

  private saveToLocalStorage(websites: Website[]): void {
    localStorage.setItem('monitored-websites', JSON.stringify(websites));
  }
}