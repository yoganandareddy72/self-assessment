import { Component, Input, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Website } from '../../models/website.model';
import { MonitoringService } from '../../services/monitoring.service';
import { Chart, ChartConfiguration, registerables } from 'chart.js';

Chart.register(...registerables);

@Component({
  selector: 'app-website-card',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="card fade-in">
      <div class="flex justify-between items-center mb-3">
        <div class="flex items-center">
          <span [class]="getStatusClass()"></span>
          <h4 class="font-semibold text-lg">{{ website.name }}</h4>
        </div>
        <button
          (click)="removeWebsite()"
          class="btn btn-danger"
          title="Remove website"
        >
          ×
        </button>
      </div>
      
      <div class="mb-3">
        <p class="text-sm text-gray-600 mb-1">{{ website.url }}</p>
        <p class="text-sm text-gray-500">
          Last checked: {{ formatTime(website.lastChecked) }}
        </p>
        <div *ngIf="website.status === 'down'" class="mt-2 p-2 bg-red-50 border border-red-200 rounded">
          <p class="text-sm text-red-700">
            ⚠️ Website appears to be unreachable or down
          </p>
        </div>
        <div *ngIf="website.status === 'checking'" class="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded">
          <p class="text-sm text-yellow-700">
            🔄 Checking website status...
          </p>
        </div>
      </div>
      
      <div class="grid grid-cols-3 gap-4 mb-4">
        <div class="text-center">
          <p class="text-2xl font-bold" [class]="getStatusTextColor()">
            {{ getStatusText() }}
          </p>
          <p class="text-sm text-gray-500">Status</p>
        </div>
        
        <div class="text-center">
          <p class="text-2xl font-bold text-blue-600">
            {{ website.responseTime || 'N/A' }}{{ website.responseTime ? 'ms' : '' }}
          </p>
          <p class="text-sm text-gray-500">Response Time</p>
        </div>
        
        <div class="text-center">
          <p class="text-2xl font-bold" [class]="getUptimeColor()">
            {{ website.uptime }}%
          </p>
          <p class="text-sm text-gray-500">Uptime</p>
        </div>
      </div>
      
      <div class="status-chart">
        <h5 class="text-sm font-semibold mb-3">Status History</h5>
        <div class="chart-wrapper">
          <canvas #statusChart width="400" height="200"></canvas>
        </div>
        <div class="mt-3 text-xs text-gray-500 flex justify-center gap-4">
          <span class="flex items-center">
            <span class="inline-block w-3 h-3 bg-green-500 rounded mr-1"></span>Online
          </span>
          <span class="flex items-center">
            <span class="inline-block w-3 h-3 bg-red-500 rounded mr-1"></span>Offline
          </span>
          <span class="flex items-center">
            <span class="inline-block w-3 h-3 bg-blue-500 rounded mr-1"></span>Response Time
          </span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .status-chart {
      border-top: 1px solid #e5e7eb;
      padding-top: 1rem;
    }
    
    .chart-wrapper {
      position: relative;
      height: 200px;
      margin-bottom: 1rem;
    }
    
    .text-blue-600 {
      color: #2563eb;
    }
    
    .text-green-600 {
      color: #16a34a;
    }
    
    .bg-red-50 {
      background-color: #fef2f2;
    }
    
    .bg-yellow-50 {
      background-color: #fffbeb;
    }
    
    .border-red-200 {
      border-color: #fecaca;
    }
    
    .border-yellow-200 {
      border-color: #fde68a;
    }
    
    .text-red-700 {
      color: #b91c1c;
    }
    
    .text-yellow-700 {
      color: #a16207;
    }
    
    .rounded {
      border-radius: 0.375rem;
    }
    
    .p-2 {
      padding: 0.5rem;
    }
    
    .mt-2 {
      margin-top: 0.5rem;
    }
    
    .mt-3 {
      margin-top: 0.75rem;
    }
    
    .mb-3 {
      margin-bottom: 0.75rem;
    }
    
    .mr-1 {
      margin-right: 0.25rem;
    }
    
    .inline-block {
      display: inline-block;
    }
    
    .text-xs {
      font-size: 0.75rem;
    }
    
    .gap-4 {
      gap: 1rem;
    }
    
    .justify-center {
      justify-content: center;
    }
    
    .items-center {
      align-items: center;
    }
  `]
})
export class WebsiteCardComponent implements OnInit, OnDestroy {
  @Input() website!: Website;
  @ViewChild('statusChart', { static: true }) chartRef!: ElementRef<HTMLCanvasElement>;
  
  private chart: Chart | null = null;

  constructor(private monitoringService: MonitoringService) {}

  ngOnInit(): void {
    this.createChart();
  }

  ngOnDestroy(): void {
    if (this.chart) {
      this.chart.destroy();
    }
  }

  ngOnChanges(): void {
    if (this.chart) {
      this.updateChart();
    }
  }

  private createChart(): void {
    const ctx = this.chartRef.nativeElement.getContext('2d');
    if (!ctx) return;

    const chartData = this.getChartData();

    const config: ChartConfiguration = {
      type: 'line',
      data: {
        labels: chartData.labels,
        datasets: [
          {
            label: 'Status',
            data: chartData.statusData,
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.4,
            yAxisID: 'y'
          },
          {
            label: 'Response Time (ms)',
            data: chartData.responseTimeData,
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            borderWidth: 2,
            fill: false,
            tension: 0.4,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false,
        },
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            callbacks: {
              title: (context) => {
                return `Time: ${context[0].label}`;
              },
              label: (context) => {
                if (context.datasetIndex === 0) {
                  return `Status: ${context.parsed.y === 1 ? 'Online' : 'Offline'}`;
                } else {
                  return `Response Time: ${context.parsed.y}ms`;
                }
              }
            }
          }
        },
        scales: {
          x: {
            display: true,
            title: {
              display: true,
              text: 'Time'
            },
            grid: {
              display: false
            }
          },
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            title: {
              display: true,
              text: 'Status'
            },
            min: 0,
            max: 1,
            ticks: {
              stepSize: 1,
              callback: function(value) {
                return value === 1 ? 'Online' : 'Offline';
              }
            },
            grid: {
              color: 'rgba(0, 0, 0, 0.1)'
            }
          },
          y1: {
            type: 'linear',
            display: true,
            position: 'right',
            title: {
              display: true,
              text: 'Response Time (ms)'
            },
            min: 0,
            grid: {
              drawOnChartArea: false,
            },
          }
        }
      }
    };

    this.chart = new Chart(ctx, config);
  }

  private updateChart(): void {
    if (!this.chart) return;

    const chartData = this.getChartData();
    this.chart.data.labels = chartData.labels;
    this.chart.data.datasets[0].data = chartData.statusData;
    this.chart.data.datasets[1].data = chartData.responseTimeData;
    this.chart.update();
  }

  private getChartData(): { labels: string[], statusData: number[], responseTimeData: number[] } {
    const history = this.website.statusHistory.slice(-20); // Show last 20 points
    
    const labels = history.map(point => 
      point.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    );
    
    const statusData = history.map(point => point.status === 'up' ? 1 : 0);
    const responseTimeData = history.map(point => point.responseTime || 0);

    // If no history, show placeholder data
    if (history.length === 0) {
      return {
        labels: ['No data'],
        statusData: [0],
        responseTimeData: [0]
      };
    }

    return { labels, statusData, responseTimeData };
  }

  getStatusClass(): string {
    return `status-indicator status-${this.website.status}`;
  }

  getStatusText(): string {
    switch (this.website.status) {
      case 'up': return 'UP';
      case 'down': return 'DOWN';
      case 'checking': return 'CHECKING';
      default: return 'UNKNOWN';
    }
  }

  getStatusTextColor(): string {
    switch (this.website.status) {
      case 'up': return 'text-green-600';
      case 'down': return 'text-red-600';
      case 'checking': return 'text-yellow-600';
      default: return 'text-gray-600';
    }
  }

  getUptimeColor(): string {
    if (this.website.uptime >= 95) return 'text-green-600';
    if (this.website.uptime >= 80) return 'text-yellow-600';
    return 'text-red-600';
  }

  formatTime(date: Date): string {
    return new Intl.RelativeTimeFormat('en', { numeric: 'auto' }).format(
      Math.round((date.getTime() - Date.now()) / 1000 / 60),
      'minute'
    );
  }

  removeWebsite(): void {
    this.monitoringService.removeWebsite(this.website.id);
  }
}