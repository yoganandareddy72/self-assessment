import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MonitoringService } from '../../services/monitoring.service';

@Component({
  selector: 'app-add-website',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="card">
      <h3 class="text-xl font-semibold mb-4">Add New Website</h3>
      <form (ngSubmit)="addWebsite()" class="space-y-4">
        <div>
          <label for="url" class="block text-sm font-semibold mb-2">Website URL</label>
          <input
            type="url"
            id="url"
            [(ngModel)]="url"
            name="url"
            placeholder="https://example.com"
            class="form-input"
            required
          />
        </div>
        <div>
          <label for="name" class="block text-sm font-semibold mb-2">Display Name (optional)</label>
          <input
            type="text"
            id="name"
            [(ngModel)]="name"
            name="name"
            placeholder="My Website"
            class="form-input"
          />
        </div>
        <button
          type="submit"
          [disabled]="!url"
          class="btn btn-primary w-full"
          [class.opacity-50]="!url"
        >
          Add Website
        </button>
      </form>
    </div>
  `,
  styles: [`
    .space-y-4 > * + * {
      margin-top: 1rem;
    }
    
    .w-full {
      width: 100%;
    }
    
    .opacity-50 {
      opacity: 0.5;
      cursor: not-allowed;
    }
    
    .block {
      display: block;
    }
  `]
})
export class AddWebsiteComponent {
  url = '';
  name = '';

  constructor(private monitoringService: MonitoringService) {}

  addWebsite(): void {
    if (this.url.trim()) {
      this.monitoringService.addWebsite(this.url.trim(), this.name.trim());
      this.url = '';
      this.name = '';
    }
  }
}