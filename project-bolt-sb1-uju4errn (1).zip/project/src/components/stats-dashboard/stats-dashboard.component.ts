import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs';
import { MonitoringService } from '../../services/monitoring.service';
import { MonitoringStats } from '../../models/website.model';

@Component({
  selector: 'app-stats-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8" *ngIf="stats$ | async as stats">
      <div class="card text-center">
        <div class="text-3xl font-bold text-blue-600 mb-2">{{ stats.totalSites }}</div>
        <div class="text-sm text-gray-600">Total Sites</div>
      </div>
      
      <div class="card text-center">
        <div class="text-3xl font-bold text-green-600 mb-2">{{ stats.activeSites }}</div>
        <div class="text-sm text-gray-600">Active Sites</div>
      </div>
      
      <div class="card text-center">
        <div class="text-3xl font-bold text-red-600 mb-2">{{ stats.downSites }}</div>
        <div class="text-sm text-gray-600">Down Sites</div>
      </div>
      
      <div class="card text-center">
        <div class="text-3xl font-bold text-purple-600 mb-2">{{ stats.averageResponseTime }}ms</div>
        <div class="text-sm text-gray-600">Avg Response Time</div>
      </div>
    </div>
  `,
  styles: [`
    .text-purple-600 {
      color: #9333ea;
    }
    
    .text-red-600 {
      color: #dc2626;
    }
    
    @media (max-width: 768px) {
      .md\\:grid-cols-4 {
        grid-template-columns: repeat(2, 1fr);
      }
    }
  `]
})
export class StatsDashboardComponent implements OnInit {
  stats$!: Observable<MonitoringStats>;

  constructor(private monitoringService: MonitoringService) {}

  ngOnInit(): void {
    this.stats$ = this.monitoringService.getMonitoringStats();
  }
}