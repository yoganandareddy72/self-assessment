export interface Website {
  id: string;
  url: string;
  name: string;
  status: 'up' | 'down' | 'checking';
  responseTime: number;
  lastChecked: Date;
  statusHistory: StatusPoint[];
  uptime: number;
}

export interface StatusPoint {
  timestamp: Date;
  status: 'up' | 'down';
  responseTime: number;
}

export interface MonitoringStats {
  totalSites: number;
  activeSites: number;
  downSites: number;
  averageResponseTime: number;
}